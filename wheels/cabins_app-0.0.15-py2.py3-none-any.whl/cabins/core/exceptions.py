class MisconfiguredModel(Exception):
    pass
