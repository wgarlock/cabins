class MisconfiguredModel(Exception):
    pass


class SerializerError(Exception):
    pass
