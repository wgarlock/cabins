default_app_config = 'cabins.back.apps.BaseConfig'
