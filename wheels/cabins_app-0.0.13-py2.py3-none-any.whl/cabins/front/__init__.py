default_app_config = 'cabins.front.apps.BaseConfig'
