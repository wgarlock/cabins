default_app_config = 'cabins.api.apps.BaseConfig'
