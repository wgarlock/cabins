from django.dispatch import Signal

base_page_save = Signal()
